module.exports = {
  env: {
    browser: true,
    node: true,
    es2020: true,
  },
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 2020,
    sourceType: 'module',
    ecmaFeatures: {
      jsx: true,
    },
  },
  plugins: ['@typescript-eslint', 'react', 'prettier'],
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:react/recommended',
    'plugin:react-hooks/recommended',
    'plugin:import/errors',
    'plugin:import/warnings',
    'plugin:import/typescript',
    'prettier',
    'prettier/@typescript-eslint',
    'prettier/react',
  ],
  settings: {
    'import/resolver': {
      alias: {
        map: [['~', './src/']],
        extensions: ['.ts', '.js', '.tsx'],
      },
    },
  },
  rules: {
    quotes: ['error', 'single'],

    // @NOTE: Too puristic
    '@typescript-eslint/ban-types': ['off'], // @TODO: Disable only baning {}
    '@typescript-eslint/no-namespace': ['off'],

    // @NOTE: We decided against prop validations
    'react/prop-types': ['off'],

    'import/no-cycle': ['warn'],

    // @NOTE: ОБЯЗАТЕЛЬНО нужно указывать все зависимости
    'react-hooks/exhaustive-deps': ['error'],
  },
};
